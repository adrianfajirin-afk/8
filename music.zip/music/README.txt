Taruh 15 file musik di sini dengan nama PERSIS:
bgm-1.mp3
bgm-2.mp3
bgm-3.mp3
...
bgm-15.mp3

Foto tanpa VN dari tamu bakal otomatis dapet salah satu dari 15 lagu ini
(dipilih random tapi tetap per foto, lihat komentar di script.js bagian
GANTI DI SINI poin 5 untuk detailnya). File README ini boleh dihapus
kalau musiknya udah lengkap semua.
